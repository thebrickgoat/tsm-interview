export const INFO = {
  phone: "",
  email: "",
  address: "",
  companyName: "TSM",
};

export const API_URL = {
  contactForm:
    "https://tsmdesigncatalog.com/[name]/wp-json/contact-form-7/v1/contact-forms/6/feedback",
};
