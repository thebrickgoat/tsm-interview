module.exports = [
  {
    name: "Facebook",
    href: "#",
  },
  {
    name: "Youtube",
    href: "#",
  },
  {
    name: "Instagram",
    href: "#",
  },
  {
    name: "Tiktok",
    href: "#",
  },
];
