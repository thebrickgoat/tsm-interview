import ContactForm from "./ContactForm";

const ContactPage = () => {
  return (
    <>
      <ContactForm />
    </>
  );
};

export default ContactPage;
