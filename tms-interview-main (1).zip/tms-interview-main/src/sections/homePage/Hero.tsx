const Hero = () => {
  return <section className="hero"></section>;
};

export default Hero;
