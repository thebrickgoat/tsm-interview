import Hero from "./Hero";

const HomePage = () => {
  return (
    <>
      <Hero />
    </>
  );
};

export default HomePage;
